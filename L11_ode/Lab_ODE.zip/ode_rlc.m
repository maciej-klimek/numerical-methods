% lab07_ex_rlc.m - transfer function and frequency response of RLC circuit
clear all; close all;

R = 10;                   % resistance in ohms
L = 2*10^(-3);            % inductance in henrys
C = 5*10^(-6);            % capacitance in farads

w0  = 1/sqrt(L*C);        f0 = w0/(2*pi),       % undumped resonance frequency 
ksi = (R/L)/(2*w0),                             % should be smaller than 1 
w1  = w0*sqrt(1-ksi^2);   f1 = w1/(2*pi), pause % damped resonance frequency
   
b = [ 1 ];                % coeffs of nominator polynomial
a = [ L*C, R*C, 1 ];      % coeffs of denominator poly (from the highest order)
%z = roots(b), p = roots(a), gain = b(1)/a(1),   % coeffs --> roots, gain
%[z,p,gain] = tf2zp(b,a), % the same in one Matlab function

f=0 : 1 : 10000; t=0:0.000001:2.5e-3; f0=0;
[ H, h ] = AFigs(b,a,f,t,f0); % figures for analog filter
